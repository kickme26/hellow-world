def new(function):
    print('function in the dectrator hello')

    def inner(*args, **kwargs):
        print("*" * 30)
        print(args)
        print(kwargs)
        print("*" * 30)
    return inner

@new
def some(a):
    print("the main function ", a)

some("hi")