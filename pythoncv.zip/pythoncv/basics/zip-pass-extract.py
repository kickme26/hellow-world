class Rank:
    def __init__(self, english1, tamil1):
        self.english1 = 40
        self.tamil1 = 30
    def marks(self):
        return self.english1 * 2, self.tamil1*2

class Raank(Rank):
    def __init__(self, eng2, tam2):
        super().__init__(Raank,self)
        self.eng2 = 50
        self.tam2 = 60
        self.english1 = 100
        self.tamil1  = 90
        return  eng2 + tam2
