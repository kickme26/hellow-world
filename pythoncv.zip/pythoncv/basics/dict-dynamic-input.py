# a = []
# print("enter the input: ")
# n = int(input())
# for i in range(n):
#     item = input()
#     a.append(item.strip().split())
# s = dict(a)
# print(s)
#
# for j in range(n):
#     key = input()
#     print(key)
#     print(type(key))
#
#     if key in s:
#         p = (key, "=", s.get(key))
#         print(p)
#     else:
#         print("not found")
# load additional Python modules
import socket
