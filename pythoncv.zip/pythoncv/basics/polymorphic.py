#a function with same name used for different operation


def addi(x,y,z = 0):
    c = x + y + z
    return c
ans = addi(4,5)
ans2 = addi(3,5,4)
print(ans)
print(ans2)



#example 2

#len is used for calculating both the length of string value and list value


print(len("abcds"))
print(len(["as",3,4,"234"]))



def ad(x,y):
    print( x+y)
def ad(x,y):
    print( x - y)
ad(2,4)
ad(2,4)