# # import textwrap
# # string = "sdfjkndsjlnf"
# # w = "  \n".join(textwrap.wrap(string, 4))
# # print(w)
# d ='''   kk b:  fuodh
# :SF
# svbfdhns dfb
# f :fsbu:bs fsd vkj
# sd :sdvjbfk v
# sflvhns dv
# jkbsvd :fdvmsd jbsv fsdv :svnv'''
# for i in d.splitlines():
#     if i.lstrip().startswith("f"):
#         print(i.split(":")[1])


x = 20
w = len(format(x, 'b'))
for i in range(x + 1):
    print(i, str("{0:o}".format(i)).rjust(w), str("{0:x}".format(i).upper()).rjust(w), str("{0:b}".format(i)).rjust(w))

# # i =5000
# # j =6000
# x = int(input("init"))
# y = int(input("end"))
# for i in range(x,y):
#     if i%7==0 and i%5==0:
#         print(i)

