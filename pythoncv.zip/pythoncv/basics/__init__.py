# # i =5000
# # j =6000
# x = int(input("init"))
# y = int(input("end"))
# for i in range(x,y):
#     if i%7==0 and i%5==0:
#         print(i)
'''import itertools
# x = ([1, 2], [3, 4])
# print(list((itertools.product(*x))))
# b = [int(y) for y in input().split()]3
# a = [int(x) for x in input().split()]
# print (*itertools.product(a, b))
# from itertools import product
a = map(input().split())
b = map(input().split())
print(*itertools.product(a,b))
# print(*product(list(map(int, input().split())), list(map(int, input().split()))))'''

'''
import itertools
# x = [''.join(x) for x in input().upper()]
# y = int(input())
# print((sorted((itertools.permutations(x, y)))))
a, b = input().split()
for x in itertools.permutations(sorted(str(a).upper()), int(b)):
    print((''.join(x)))'''


'''

import itertools

s,k = input().split()

for i in range(int(k)):
        for l in itertools.combinations(sorted(s), i+1):
                print( ''.join(l) )'''


'''import itertools
a, b = input().split()
for j in itertools.combinations_with_replacement((sorted(str(a).upper())), int(b)):
    print(''.join(j))'''

import collections
import itertools
# n = 11223331
#
# from itertools import groupby
# for k, g in groupby(input()):
#     l = len(list(g))
#     k = int(k)
#     print ((l, k), end=' ')
#
#


n = 1234
print(list(itertools.permutations(str(n), 2)))
print(list(itertools.combinations(str(n), 2)))

# # i =5000
# # j =6000
# x = int(input("init"))
# y = int(input("end"))
# for i in range(x,y):
#     if i%7==0 and i%5==0:
#         print(i)

print(hex(32))
















