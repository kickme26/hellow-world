def hi(a):
    b = a+a
    return b

a = hi(9) + 10

print(a)


def sum(a):
    for i in range(a):
        yield i*2

a=sum(5)
print(a)
print()
# print(next(a))
# print(next(a))

for i in a:
    print (i)
