# li = ["DOG", "VAN", "CAR"]
# lam = lambda x: x.startswith('V')
# D= lam("VAN")
# # print(D)


# def x(*argv):
#     for arg in argv:
#         if arg[0]=="s":
#             print((arg))
#
#
#
# x("ak", "dk", "ck", "sk", "siu")
#


# def function(x):
#     letters = ["a", "e","i","o"]
#     if (x in letters):
#         return x
#     else:
#         return False
# lis = ['a','d','f','r','g','i']
# def guna()


# num = [21, 19, 18, 46, 6, 29]
#
# a = []
#
#
# def guna(fun, num):
#     for i in num:
#         if i % fun == 0:
#
#             a.append(i)
#     print(a)
#
#
# guna(3, num)
#
# #print(guna(lambda x: x+3,num))
#
#
# #
# #
# #
# # def guna(fun, num):
# #     a = []
# #     for i in num:
# #         a.append(i)
# #     return a
# #
# # num = [21, 19, 3, 18, 46, 6, 29]
# #
# #
# #
# #
# # d=guna(lambda x: x==3, num)
# # print(d)

import  re
patt = '^[7-9]{1}\d{9}$'
for i in range(int(input())):
    st = input()
    check = re.match(patt, str(st))
    if check:
        print("YES")
    else:
        print("NO")