a = []
total_input = int(input("print how many element :  "))
for i in range(total_input+1):
    elements = int(input("enter the elements:  "))
    a.append(elements)

print(a)
while True:
    for i in a:
        if i == 3:
            print(" yes ")
#y

# i = 10
# e = int(input("num"))
# while i > int(e):
#     e = e + 4
#     print("nope")
#     print(e)
#     break
# print("greater",e)


from multiprocessing import Process, Pipe
import time

st = time.time()
def f(conn):
    conn.send(['hello world'])
    conn.close()


if __name__ == '__main__':
    parent_conn, child_conn = Pipe()
    p = Process(target=f, args=(child_conn,))
    p.start()
    print(parent_conn.recv())
    p.join()
    end = time.time()
    print(end - st)