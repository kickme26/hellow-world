
# def sum():
#     print("enter the element: ")
#     a= int(input())
#     b = int(input())
#     c = a+b
#     print(c)
# def sub(a,b):
#     print(f"subrated value for {a} - { b} is:",a-b)
#
#
# sub(2,1)
# sum()












