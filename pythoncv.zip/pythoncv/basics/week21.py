

'''class one:
    def __init__(self,c):
        self.b = 100
        self.c = c
    def sample(self):
        print("class A")
        print( self.b,self.c)
class two(one):
    def sample(self):
        print("class B")
        print(self.c)
    #print(b)
b1 = one(200)
b1.sample()
a1  = two(b1)
a1.sample()'''

import os

print(os.listdir())
d = os.chdir('C:\\Users\jouve\Documents')
print(d)

e = open('gu.txt')
print("success",os.listdir('C:\\Users\jouve\Documents'))
print(open('gu.tx'
           't'))