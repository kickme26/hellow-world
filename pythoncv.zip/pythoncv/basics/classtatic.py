# import re
# mail = "username@gmail.com,ysabsha@dsdjk.cid"
# x = re.findall(r"(\w+)@", mail)
# y = re.search(r"(\w+)@(\w+).(\w+)",mail)
# print(x)
# print(y.group(1, 2, 3))
# print(y.groups())

import re

string = "hagd 4 g r43yu 4 f43 43  43 "
x = re.findall(r"\d+", string)
print(x)
