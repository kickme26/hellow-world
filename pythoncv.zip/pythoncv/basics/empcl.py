import sys
# class Employee:
#     def __init__(self,name,id):
#         self.name = name
#         self.id = id
#     def emp(self):
#         print(self.name,self.id)
# e1 = Employee("guna",2)
# e2 = Employee("hel",2)
# e1.emp()
# e2.emp()
# print(getattr(e1,"id"))
# a = ['my', 'prem', ]
# c = 'as'
# b = ['kumar', 'ram']
#
#
# d = []
# for x in a:
#     d.append(x)
#
# d.append(c)
# for x in b:
#     d.append(x)
#
# print(d)zs
# a = ''.join(d)
# print(a)
# a = [1, 2, 3, 4]
# b = [1, 2, 3, 5]
# for i in enumerate(a):
#     print(i)
# d = zip(i)
# print(d)
from itertools import combinations
import sys

l = [1, -1, 5, 7, 10]
# d = [x+3 for x in l]
# print(d)
# o/p :[4,6,8,10,13]

for i in l:
    if l[0] < l[1]:
        l[1]=l[1+1]
    else:
        l[0], l[1] = l[1], l[0]
        l[0] = l[0+1]
        print(l[0], l[1])
print(l)
