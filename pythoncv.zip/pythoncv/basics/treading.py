from multiprocessing import Process
import time
start = time.time()


def f():
    c = 5 + 5
    print(c)


if __name__ == '__main__':
    fc = Process(target=f)
    fc.start()
    fc.join()
    end = time.time()
    print(end - start)