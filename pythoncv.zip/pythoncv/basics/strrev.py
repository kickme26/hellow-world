def stringrev(x):
    print("reverse of the string is: \t",x[::-1].expandtabs(30).rjust(10,"*").ljust(10,"*"))
    print("\nthe  reversed  value  is:  \t","".join(reversed(x.expandtabs(30))).ljust(10,"*"))

if __name__ == '__main__':
    print("\n",__name__,"\n")
    stringrev('doogg')