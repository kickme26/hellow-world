import json
z = {"name":"raju",
     "age":23, "city":"paris",
     "married": True,
     "childrens":("rama","seema"),
     "pets":None,
     "cars":[{"bmw":"black"},
             {"audi":"white"}
             ]}
print(json.dumps(z,sort_keys=True))
