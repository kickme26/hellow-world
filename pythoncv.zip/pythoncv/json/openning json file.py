import json
file = open(r"C:\Users\jouve\PycharmProjects\untitled1\python cv\json\f1.json")
data = json.load(file)
print(data)
dump = json.dumps(data,sort_keys=True)
print(dump)