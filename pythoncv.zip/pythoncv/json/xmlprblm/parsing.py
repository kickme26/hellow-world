from lxml import etree as et
tree = et.parse('treee')
root = tree.getroot()
print(root.tag)
# for i in root:
#     print(i.tag, i.attrib)   # prints ths total tag and attributes
# for i in root.iter('book'):
#     print(i.attrib)
# print([i.attrib for i in root.iter('book')])
print(tree.getroot().tag)
for child in root:
    print(root.tag, root.attrib, "==", child.tag, child.attrib)
print(root[0][0].text)
print(root[0][1].text)
print(root[0][1].tag)
print("------------")
for i in root[0]:             # root is used to get all the attributes.with []we can get the attributes
    print("___", i.tag)       # prints the tag {heading}.
    print(i.text)             # text is used to print the statement


print(root[0].attrib)