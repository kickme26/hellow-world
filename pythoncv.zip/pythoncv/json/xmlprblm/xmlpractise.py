from lxml import etree
tree = etree.parse("treee")
root = tree.getroot()
print(root)
# for i in root.iter('price'):
#     print(i.text)
# for i in root.iter('title'):
#     print(i.text )
# for pri in root.iter('price'):
#     if float(pri.text) > 30:
#         print(pri.text)
for i in tree.iter():
    print(i.tag, i.attrib)
print("==",root[0].parent().ta)