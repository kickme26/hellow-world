import os
from lxml import etree

root = etree.Element('html')
etree.SubElement(root, 'head')
etree.SubElement(root, 'title')
etree.SubElement(root, 'body')
x = (etree.tostring(root, pretty_print=True).decode("utf-8"))
new = etree.ElementTree(root)
print(x)
"with open(newfile, wb)as f:"
"f.write(etree.tostring(new))"
print(x[0], x[1], x[3])  # since they store data as list they prints the index element
print(root[0])           # prints the object

h = root[0]              # !--> accessing the elemnent tag by the root index <---
hh = root[2]

print(h.tag)
print(hh.tag)

for i in root:
    print("--", i.tag)

etree.SubElement(root, 'head').text = "this is head"
etree.SubElement(root, 'body').text = "this is bad"
print(etree.tostring(root, pretty_print=True).decode("utf-8"))
print("_____", etree.tostring(root, pretty_print=True))
h =  etree.fromstring(x)
print(h.tag)

