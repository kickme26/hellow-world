from lxml import etree
from io import StringIO
import re
import os
x = StringIO("<!ELEMENT b EMPTY>")
dtd = etree.DTD(x)
root = etree.XML('''<catalog>
   <book id="bk101">
      <author>Gambardella, Matthew</author>
      <title>XML Developer's Guide</title>
      <genre>Computer</genre>
      <price></price>
      <publish_date>2000-10-01</publish_date>
      <description>An in-depth look at creating applications 
      with XML.</description>
   </book>''')

print(etree.tostring(root, pretty_print=True).decode("utf-8"))
# with open("nee", "wb")as f:
#     f.write(etree.tostring(root))
x = open(r"C:\Users\jouve\PycharmProjects\untitled1\pythoncv\json\nee")
li = (str(list(x)))
print(li)
print("\n", re.findall(r"<(\w+)/>", li))
print(dtd.validate(root))


