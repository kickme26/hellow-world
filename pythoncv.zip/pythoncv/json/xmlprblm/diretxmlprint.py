from lxml import etree
root = etree.XML('''<html>
  <head/>
  <title/>
  <body/>
  <head>this is head</head>
  <body>this is bad</body>
</html>''')
print(etree.tostring(root, pretty_print=True).decode("utf-8"))
print("__", etree.tostring(root))
print(root[1].tag)
print("++",)