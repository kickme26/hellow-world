import json
x ='{"name":"guna","age":21,"city":"dubai"}'   #the object json
y ={"name":"raju","age":23, "city":"paris"}

load = json.loads(x)
print(load)
print(load["name"])
dump = json.dumps(y)
print(dump)
#print(dump["name"])

#if i try to access th json like dict mehod in 10th line: bcz its in json format

