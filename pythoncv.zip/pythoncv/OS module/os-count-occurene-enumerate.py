import random
import os
from collections import Counter
os.chdir("E:\\stest\\scratches")

f = open("dlfile.txt","r")
d = f.read().splitlines()
e = Counter(d)
print(e)
# n = str(input("enter:  "))
# temp_lis = []
# #print( [s for s in enumerate(d) if n in s])
# for i in enumerate(d):
#     if n in i:
#         temp_lis.append(i)
#         print(i,n)
#
# #enumerate prints tuple with the index
# print("the occurrence list is: ",temp_lis)
# print("enter the index to delete ")
# nth_occ = int(input(": "))
# after_rem = temp_lis.remove(temp_lis[nth_occ])
# print(temp_lis)
#
#

import random
import os
from collections import Counter
os.chdir("E:\\stest\\scratches")

f = open("dlfile.txt","r")
d = f.read().splitlines()
e = Counter(d)
print(list(e))
n = str(input("enter:  "))
#print( [s for s in enumerate(d) if n in s])
for i in enumerate(d):
    if n in i:
        print(list(i))

#enumerate prints tuple with the index

print("enter the index to delete ")
nth_occ = int(input(": "))
ans = d.remove(n(nth_occ))
print(d)































