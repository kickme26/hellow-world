#[printing last line in a text file]

import os
print(os.chdir("E:\\stest\\scratches"))
file = open("dlfile.txt","r")
read = file.readlines()
le = len(read)
print(le)
print(read[le-1])
