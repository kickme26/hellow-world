#reading the lines line by line and printing it as a list


#list

import os
os.chdir("E:\\stest\\scratches")
f = open("dlfile.txt","r+")
ll = f.readlines()
print(ll)



#reading the txt file and storinig them in an array

#array

import os
os.chdir("E:\\stest\\scratches")

with open("dlfile.txt",'r+') as f:
    ar =[]
    for i in f:
        ar.append(i)
    print(ar)