import os
import collections
#print(os.getcwd())
#print(os.listdir('E:\\stest\\scratches'))
print(os.chdir(r"C:\Users\jouve\PycharmProjects\untitled1\pythoncv\practise"))
f = open("dlfile.txt", "r").read()
lin = 0

for i in f.split(" "):
    lin = lin+1

print(lin)
p

