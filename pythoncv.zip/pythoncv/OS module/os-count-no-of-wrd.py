
#counting number of words in  file...

from collections import Counter
import os
os.chdir("E:\\stest\\scratches")
f = open("dlfile.txt","r")
word = f.read().splitlines()
count = 0
for i in word:
    count = count+1
print(count)