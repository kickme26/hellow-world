#printing the max length of the word in the file

import os
os.chdir("E:\\stest\\scratches")
with open("dlfile.txt") as f:
    word = f.read().split()
max1 = max(word,key=len)
print(max1)
mi = min(word,key = len)
print(mi)