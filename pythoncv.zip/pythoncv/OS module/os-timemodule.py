import os
import time
import calendar
from termcolor import colored
n = input(("enter s to chek time and d to check date : "))
if n == "s":
    print(time.ctime())
    print("\nthe local time is: ",time.asctime(time.localtime(time.time())))
    time.sleep(2)
    print(calendar.month(2015,5))
    print("\n ****",time.ctime())
    print("\n",time.asctime(time.localtime()))
    print(calendar.firstweekday())
    print(calendar.isleap(2109))
    print(calendar.leapdays(1998,2019))
    print(calendar.monthrange(1998,2))