
#counting the number of lines in a file


import os
os.chdir("E:\\stest\\scratches")
l =0
f = open("dlfile.txt","r").read().splitlines()
for li in f:
    l +=1
print(l)

