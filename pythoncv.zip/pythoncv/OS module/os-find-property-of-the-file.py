#using stat finds the size and time of the file
import os
os.chdir("E:\\stest\\scratches")
f = open("dlfile.txt")
p = "E:\\stest\\scratches\\dlfile.txt"
print(os.listdir())
print(os.stat(p).st_size)
print(os.stat("E:\\stest\\scratches\\hay.txt").st_size)