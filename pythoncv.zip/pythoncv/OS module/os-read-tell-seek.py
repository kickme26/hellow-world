import os
f = open("new num.txt",mode="w",encoding="utf-8")
for i in range(30):
    f.write("sample %s",%("ghffghf"))