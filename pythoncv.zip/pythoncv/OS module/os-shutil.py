#copy th eile to another file

#join the f1 line and f2 line


import os
import  shutil
from shutil import copyfile

shutil.
import shutil
os.chdir("E:\\stest\\scratches")
copyfile("dlfile.txt", "gh.txt")
f1 = open("dlfile.txt")
f2 = open("gh.txt")
for i, j in (f1, f2):
    print(i+j)