import os
os.chdir(r"E:\stest\scratches")
f = open(r"E:\stest\scratches\dlfile.txt","r")
data = f.readlines()

for line in data:
    words = line.split()
    print(words)