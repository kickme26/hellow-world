from collections import Counter
import os
os.chdir(r"E:\stest\scratches")
file = open(r"E:\stest\scratches\dlfile.txt","r")
d = Counter(file)
print((d))

c = Counter
co = c(a=1,b =2,c=8)
print(co)