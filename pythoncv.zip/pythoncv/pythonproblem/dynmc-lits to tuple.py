l = []
def number(*args):
    for i in args:
        l.append(i)
    x = tuple(l)
    print(l)
    print(x)


number(33, 44, 33, 22, 33)