#
# n = str(input(" : "))
# l = list(n)
# print(sorted(''.join(l)))


# length of words in list
l = [1, 2, 3]
print(list(map(len,["sfv", "efw", "efvfw"])))


import itertools
k = [1, 23, 3]
print(list(itertools.combinations(k, 2)))