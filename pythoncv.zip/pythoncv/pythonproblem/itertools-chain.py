import itertools
a = [1, 34, 5]
b = [2, 10, 3443]
print(sorted(list(set((itertools.chain(a, b))))))