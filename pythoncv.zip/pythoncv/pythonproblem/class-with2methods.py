# one method without using get_str

"""class sample:
    def __init__(self, string):
        self.string = string

    def convert(self):
        y = self.string.upper()
        return y


x = sample("aahbdjs sidu ghd gsd")
print(x.convert())"""

# another method using get_str

class sampleclass:
    count = 10 # class attribute

    def increase(self):
        sampleclass.count += 1


# Calling increase() on an object
s1 = sampleclass()
s1.increase()
print(s1.count)

# Calling increase on one more
# object
s2 = sampleclass()
s2.increase()
print(s2.count)

print(sampleclass.count )
