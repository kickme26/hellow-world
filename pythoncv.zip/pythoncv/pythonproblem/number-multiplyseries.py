d = dict()


def number(x):
    for i in range(x+1):

        d[i] = i*i
        print(d[i])     # dict key
    return d            # dictionary

number(10)
