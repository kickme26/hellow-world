import itertools
string = "1234"
d = list(itertools.permutations(string.strip(', '), 2))  # number changes its position no same number
x = list(itertools.combinations_with_replacement(string, 2))  # doesnt change position and same number occurs
v = list(itertools.combinations(string.strip(', '), 2))  # try its combo without changing its position
print(d)
print(x)
print(v)
print(len(d))
print(len(x))
print(len(v))
