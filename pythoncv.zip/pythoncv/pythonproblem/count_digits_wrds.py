class A:

    def __init__(self, x):
        self.x = x

    def worde(self):
        self.di = {"digit": 0, "word": 0, "upper": 0, "lower": 0}
        self.d = str(self.x).split()
        self.m = self.d
        for i in self.d:
            if i.isdigit():
                self.di["digit"] += 1
            elif i.isalpha():
                self.di["word"] += 1

            else:
                pass
        print(self.di)

    def case(self):
        A.worde(self)

        for i in self.d:
            if i.isupper():
                self.di["upper"] += 1

            elif i.islower():
                self.di["lower"] += 1
            else:
                pass
        print(self.di)

A("HIH i sdkjh h 78  uiui hdif 23 HDH hg A y  ").worde()
A("GB jg LUG  ug  UH ").case()
