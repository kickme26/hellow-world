import math


class Prob:

    def __init__(self):
        self.num = ""

    def calc(self):
        self.num = int(input())
        c = 50
        h = 30
        q = math.sqrt((2 * c * self.num)//h)
        print(q.__round__())


ob =Prob()
ob.calc()