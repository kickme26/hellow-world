balance = 0

while True:
    x = input("W to withdraw\nD  to deposit\nb  to check balance")
    if x == 'w':
        amnt = int(input("amount: "))
        if amnt >= balance:
            print(f"oh oh sorry u dont have that much,  u have only{balance}")
            continue
        else:
            balance = balance - amnt
    elif x == 'd':
        amnt = int(input("amount: "))
        balance = balance + amnt
        print(f"current balance is:{balance} ")
    elif x == 'b':
        print(f"balance  {balance}")
    else:
        break




