class A:
    def __init__(self):
        self.x = ""

    def sort(self):
        l = []
        self.x = str(input())
        n = [n for n in self.x.split(" ")]
        print((n))



b = A()
b.sort()
