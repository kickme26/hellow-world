import re
pas = "AS3s$$e3"
x = True
while x:
    if len(pas) < 8 or len(pas) > 12:
        break
    elif not re.search("[a-z]", pas):
        break
    elif not re.search("[A-Z]", pas):
        break
    elif not re.search("[0-9]", pas):
        break
    elif not re.search('[@#$%^&*()_+><?]', pas):
        break
    else:
        print("yes its valid")
        x = False
        break
if x :
    print("sorry u missing the format")