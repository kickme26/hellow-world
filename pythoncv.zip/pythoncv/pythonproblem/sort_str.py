# class sort:
#
#     def __init__(self):
#         self.string = ""
#
#     def dosort(self):
#
#         self.string = str(input())
#         x = self.string.split(',')
#         x.sort()
#         print(x)
#
#
#
# d = sort()
# d.dosort()
#
import time
s = time.process_time_ns()
c = [1, 2, 3, 4, 5]
print(c)
e = time.process_time()
print("total time is: ", e-s)
ss = time.process_time_ns()
d = (1, 2, 3, 4, 5)
print(d)
ee = time.process_time()
print("tuple time is: ", ee-ss)
