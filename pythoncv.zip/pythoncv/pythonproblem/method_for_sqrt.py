import math
import dis

def sq():
    n = int(input("enter: "))
    print(math.sqrt(n))

dis.dis(sq)


# dis generates the dissamble code