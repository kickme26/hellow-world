# formula = "a + aa + aaa + aaaa"
# p = input("enter: ")
# x = (formula.replace("a", p))
# y = x.split('+')
# print(y)
# z = [int(m) for m in y]
# print(z)
# print(sum(z))
#
# # Another method
#
# n = int(input("enter: "))
# n1 = int(f"{n}")
# n2 = int(f"{n}{n}")
# n3 = int(f"{n}{n}{n}")
# n4 = int(f"{n}{n}{n}{n}")
# print(n1+n2+n3+n4)
#
import smtplib

sender_mail = 'kick123@gmail.com'
receivers_mail = ['guna26.98@gmail.com']
message = """From: From Person %s 
To: To Person %s 
Subject: Sending SMTP e-mail  
This is a test e-mail message. 
""" % (sender_mail, receivers_mail)
try:
    password = input('Enter the password')
    smtpObj = smtplib.SMTP('gmail.com', 587)
    smtpObj.login(sender_mail, password)
    smtpObj.sendmail(sender_mail, receivers_mail, message)
    print("Successfully sent email")
except Exception:
    print("Error: unable to send email")
