class A:
    def __init__(self):
        self.s = ""

    def ans(self):
        self.s = (input().split(' '))
        print(self.s)
        for i in self.s:
            print(bin(int(i)))


A().ans()