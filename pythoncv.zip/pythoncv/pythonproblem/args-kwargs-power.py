# to get n number input from the function using args

"""def series(*args):
    print("enter the range of numbers: ")
    for i in args:
        print(i)


series(1,"d","sf","fssf")"""


# using **kwargs remember to add item() and use two indexi,j

"""def kw(**kwargs):
    for i, j in kwargs.items():
        print(i, j)


kw(f="3", d="33", w="ttt") """




