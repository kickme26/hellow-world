import collections
from operator import itemgetter
n = "gfgftkgghty"
d = collections.Counter(n.split(' '))
print(d)
for i in d:
    print(i, ":", d.get(i))

#
# class Person(object):
#     def getGender(self):
#         return "Unknown"
#
#
# class Male(Person):
#     def getGender(self):
#         return "Male"
#
#
# class Female(Person):
#     def getGender(self):
#         return "Female"
#
#
# aMale = Male()
# aFemale = Female()
# aP =Person()
# print(aP.getGender())
# print(aMale.getGender())
# print(aFemale.getGender())
