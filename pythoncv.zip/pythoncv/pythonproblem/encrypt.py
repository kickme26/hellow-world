"""The image lists 3 pairs
K->M
O->Q
E->G
everybody thinks twice before solving this.
g fmnc wms bgblr rpylqjyrc gr zw fylb.
rfyrq ufyr amknsrcpq ypc dmp.
bmgle gr gl zw fylb gq glcddgagclr ylb rfyr'q ufw
rfgq rcvr gq qm jmle. sqgle qrpgle.kyicrpylq()
gq pcamkkclbcb lmu ynnjw ml rfc spj."""
#
# string = (input())
# l = list(string)
# print(l)
# for i in l:
#     if i == " ":
#         print('', end='')
#     x = ord(i)
#     if x == 121:
#         x = 97
#     if x == 122:
#         x = 98
#     else:
#         y = x+2
#         print(chr(y), end='')
""" another way is by using string.msketrans """
import string
basic = "abcdefghijklmnopqrstuvwxyz"
key_to_decodr = "cdefghijklmnopqrstuvwxyzab"
answer  = str.maketrans(basic, key_to_decodr)
str = """g fmnc wms bgblr rpylqjyrc gr zw fylb.
rfyrq ufyr amknsrcpq ypc dmp.
bmgle gr gl zw fylb gq glcddgagclr ylb rfyr'q ufw
rfgq rcvr gq qm jmle. sqgle qrpgle.kyicrpylq()
gq pcamkkclbcb lmu ynnjw ml rfc spj"""
print(str.translate(answer))