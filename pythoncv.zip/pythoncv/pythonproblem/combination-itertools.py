import itertools
# l = [1, 2, 3, 4]
# print(itertools.combinations(l, 2))   # prints objects
# print(list(itertools.combinations(l, 2)))  # using list it prints the value

# d = list(map(sum, zip([21, 4], [3, 5])))
# print(d)

class IOString():
    def __init__(self):
        self.str1 = ""

    def get_String(self):
        self.str1 = input("__")

    def print_String(self):
        print(self.str1.upper())

str1 = IOString()
str1.get_String()
str1.print_String()