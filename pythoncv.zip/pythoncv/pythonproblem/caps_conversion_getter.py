class Sa:
    def __init__(self):
        self.i = ""

    def getx(self):
        self.i = input()

    def ans(self):
        print(self.i.upper())


s = Sa()
s.getx()
s.ans()
