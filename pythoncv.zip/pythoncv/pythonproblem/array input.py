l=[]
while True:
    n = str(input())
    if n:
        l.append(n.upper())
    else:
        break
for i in l:
    print(i)
