# finding alphanumeric in the urlib by saving them in a file



import re
d = open("regexfile", "r").read()
find = re.findall("[a-z]",d)
print(find)
find = re.findall(r"[A-Za-z]", d)
print(find)