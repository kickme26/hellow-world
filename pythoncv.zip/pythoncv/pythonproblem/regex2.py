
import re
url = open("regex22", "r").read()
find = re.findall(r"[^A-Z][A-Z]{3}([a-z])[A-Z]{3}[^A-Z]+", url)
print(find)
