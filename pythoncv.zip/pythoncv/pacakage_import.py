# C:\Users\jouve\PycharmProjects\untitled1\python cv\  "basics\prime.py"
"absolute path"
# from basics import prime
# print(prime)
# sub()

#from .import prime
#sub()

# C:\Users\jouve\PycharmProjects\untitled1\python cv\  "practise\ganme.py"
# "relative path use [.] instead of parent package"
# from practise.ganme import start
# start()
# C:\Users\jouve\PycharmProjects\untitled1\python cv\newpack\time.py



from newpack.time import timee













