# class Emp:
#     def __init__(self,name,sal):
#         self.name = name
#         self.sal = sal
#         print("1",self.name,self.sal)
#
#     def mo(self):
#         print("ddfdsfd")
# class B(Emp):
#     def __init__(self):
#         print("ad")
#     def ne(self):
#         super().mo()
#
#
# e1 = B()
#
#
# e1 = B().ne()


# understanding super() and inheritance

class A:
    def one(self):
        print("111")

    def two(self):
        print("222")


# inheriting
class B(A):

    def one(self):
        print("221211212")

    def two(self):
        # without using super() calling the parent class and method.
        A.two(self)
        # use super() by inheriting the parent class and join the method we needed with super()
        super().one()
        print("222222222")


class C(A):
    def __init__(self, new_value):
        self.new_value = new_value
        print("new,", new_value)
    def moo(self):
        print('mmooo')
        super().one()

# object_creation


q = A()

q.one()
q.two()

w = B()

w.one()
w.two()

x = C(4)