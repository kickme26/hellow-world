# class Student:
#     def __init__(self, name, marks):
#         self.name = name
#         self.marks = marks
#         self.gotmarks = self.name + ' obtained ' + self.marks + ' marks'
#
#
# st = Student("Jaki", "25")
#
# print(st.name)
# print(st.marks)
# print(st.gotmarks)
# st.name = "guna"
# print(st.name)
# print(st.gotmarks)

"""
since we are trying to change the name and marks after changing the name to guna it show the output as old name

the output is:

Jaki
25
Jaki obtained 25 marks
guna


so in next program we are creating the new method :
"""


# class Student:
#     def __init__(self, name, marks):
#         self.name = name
#         self.marks = marks
#         # self.gotmarks = self.name + ' obtained ' + self.marks + ' marks'
#
#     def gotmarks(self):
#         return self.name + ' obtained ' + self.marks + ' marks'
#
#
# st = Student("Jaki", "25")
# print(st.name)
# print(st.marks)
# print(st.gotmarks())
#
# st.name = "guna"
# print(st.name)
# print(st.gotmarks())
#

'''now we are using the @property '''

#
# class D:
#     def __init__(self, name, marks):
#         self.name = name
#         self.marks = marks
#
#     @property
#     def gotmarks(self):
#         return self.name + ' got ' + self.marks + ' marks'
#
#     @gotmarks.setter
#     def gotmarks(self, value):
#         self.value = value
#
#
# obj1 = D("guna", "446")
# print(obj1.name)
# print(obj1.marks)
#
# obj1.gotmarks
# print(obj1.gotmarks)
#
# obj1.name = "bailo"
#
# print(obj1.gotmarks)
# print(obj1.name)
#
# obj1.marks = "353535"
#
# print(obj1.gotmarks)