class Book:
    def __init__(self, name, age, money,location):
        self.name = name
        self.age = age
        self.money = money
        self.location = location

    def display(self):
        print("my name is", self.name, "i have ", self.money, "$ dollars", "my age is", self.age, self.location)

    def get(self):
        return self.money


    def set(self, extra):
        self.money = self.money + extra


ob1 = Book("han", 10, 1000, "chennai")
ob1.display()

ob2 = Book("jon", 20, 10000, "dubai")
ob2.display()
ob2.set(100)
ob2.get()

ob2.display()























#
# class GFG:
#     ob3 = Book("don",12,1212)
#
#
# g = GFG()
# g.ob3 = "Geeks"
# print(g.ob3)
#
