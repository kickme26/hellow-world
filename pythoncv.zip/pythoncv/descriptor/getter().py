# use of GETATTR()

# using getattr() we can get the value of the attributes as string

# if attribute is not found you can set some default value


class D:
    def __init__(self,name):
        self.name = name
x = D("jeng yang")
x.name
print(x.name)

# we can access the attributes by calling object and string
print(getattr(x, "name"))
# also assign new attributes with default values
print(getattr(x, "age", 24))
