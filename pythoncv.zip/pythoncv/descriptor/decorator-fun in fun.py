# class C:
#     def __init__(self,name,age):
#         self.name = name
#         self.age = age
#     @property
#     def display(self):
#         return self.name , self.age
#     @display.setter
#     def display(self, gen):
#         self.gen = gen
#
# ob = C("guna" , 21)
# print(ob.display)
#
# ob.age = 22
# print(ob.display)

class py_solution:
    def int_to_Roman(self, num):
        val = [10, 9, 5, 4,1]
        syb = ["X", "IX", "V", "IV", "I" ]
        roman_num = ''
        i = 0
        while num > 0:
            for l in range(num // val[i]):
                roman_num += syb[i]
                num -= val[i]
            i += 1
        return roman_num


print(py_solution().int_to_Roman(1))
print(py_solution().int_to_Roman(6))