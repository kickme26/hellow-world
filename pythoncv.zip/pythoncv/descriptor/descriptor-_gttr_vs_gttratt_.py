
class Geta():
    attr1 = 1

    def __init__(self):
        self.attr2 = 2
        print("object created")               # __getattribute__

    def __getattribute__(self, attr):         # it invoked by default before looking the previous argument declarations
        print("get: " + attr)
        if attr == 'attr3':                   # If you need to catch every attribute regardless whether it exists or not
            print("this if condition")
            return 3
        else :
            print("this else ")
            return object.__getattribute__(self, attr)


x = Geta()
print(x.attr1)
print((x.attr2))
print(x.attr3)

# ___________________-----------------_________________________----------------________________________________________


# class Geta:
#     attr1 = 1                             #__getattr__
#
#     def __init__(self):                   #  good for implementing a ''fallback for missing'' attributes
#         self.attr2 = 2
#         print("this init function")
#
#     def __getattr__(self, attr):          # it invokes only when there is 'no declared attributes or not found'
#         print("get: " + attr)
#         if attr == 'attr3':
#             return 3
#         else:
#             raise AttributeError
#                                         # __getattr__ only gets called for attributes that don't actually exist.
#                # If you set the attribute directly,referencing that attribute will retrieve it without calling_getattr

# x = Geta()
# print(x.attr1)
# print(x.attr2)
# print(x.attr3)
