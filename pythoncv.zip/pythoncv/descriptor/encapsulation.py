class Rectangle:
    def __init__(self, length, breadth):          # called when the obj is created 
        print("__init__ call")        
        self.__length = length
        self.__breadth = breadth

    def area(self):
        return self.__length * self.__breadth

    def sets(self, value):
        self.__breadth = value

    def gets(self):
        return self.__breadth


rect1 = Rectangle(20, 2)
rect2 = Rectangle(2, 40)
print(rect1.area())
print(rect2.area())
rect2.__breadth = 100   # trying to change the breadth value in protected mode "but if we remove _ it changes the value"
print(rect2.__breadth)    # it prints the changed value
print(rect2.area())        # but the value never changed
rect2.sets(100)             # only by using the getter and setter we can change the protected value
print(rect2.area())