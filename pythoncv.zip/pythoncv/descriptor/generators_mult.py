class A:
    def __init__(self, end):
        self.end = end

    def number(self):
        z = []
        for x in range(self.end):
            if x % 7 == 0:
                z.append(x)
                yield (x)


o = A(34)
for i in o.number():
    print(i)





