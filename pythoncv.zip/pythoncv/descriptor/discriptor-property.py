import threading
class one:
    def __init__(self, number):
        self.number = number

    def met(self):
        print("now get")
        return self.number + 20

    @property
    def new(self):
        print("getting")
        return self.number

    @new.setter
    def new(self, number):
        print("setting")
        self.number = number


if __name__ == '__main__':
    x = one(3)
    print(x.new)
    print(x.number)
    x.number = 10

    print(x.number)
    print(x.met())
for i in threading.enumerate():
    print(i.getName())