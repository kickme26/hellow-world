class D:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def met1(self):
        print("teh name is: ", self.name, "my age is ", self.age)

    def __get__(self, instance, owner):
        print("getting data")
        return self.age

    def __set__(self, instance, value):
        print("setting")
        self.value = value


class E:
    ob1 = D("name", 23)


x = E()
print(x.ob1)
x.ob1 = "d"
print(x.ob1)
                                      # copied from some site for understanding
# Descriptor using _grt_ and _set_
# class MyDescriptor():
#     """
#     A simple demo descriptor
#     """
#
#     def __init__(self, initial_value=None, name='my_var'):
#         self.var_name = name
#         self.value = initial_value
#
#     def __get__(self, obj, objtype):
#         print('Getting', self.var_name)
#         return self.value
#
#     def __set__(self, obj, value):
#         msg = 'Setting {name} to {value}'
#         print(msg.format(name=self.var_name, value=value))
#         self.value = value
#
#
# class MyClass():
#     desc = MyDescriptor(initial_value='Mike', name='desc')
#     normal = 10
#
#
# if __name__ == '__main__':
#     c = MyClass()
#     print(c.desc)
#     print(c.normal)
#     c.desc = 100
#     print(c.desc)
