import subprocess
import os
import sys
process = subprocess.Popen("ipconfig", stdout=subprocess.PIPE)
display = process.communicate()[0]
d = display.decode("utf-8")
print("===============", d)
file = open("ipfile.txt","r").read()
# note = file.write(d)
for line in file.splitlines():
    if line.lstrip().startswith("IPv4"):
        print("====")
        print("__the ip address is  :",line.split(":")[1])
    elif line.lstrip().startswith("Subnet"):
        print("\n____the subnet mask is :",line.split(":")[1])
