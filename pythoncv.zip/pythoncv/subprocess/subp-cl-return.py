import subprocess
class Get:
    def ip(self):
        for line in d.splitlines():
            if line.lstrip().startswith("IPv4"):
                print("====")
                i = ("____the ip address is  :", line.split(":")[1])
                return i
    def subnet(self):
        for line in d.splitlines():
            if line.lstrip().startswith("Subnet"):
                s = ("____the subnet mask is :", line.split(":")[1])
                return s

process = subprocess.Popen("ipconfig", stdout=subprocess.PIPE)
display = process.communicate()[0]
d = display.decode("utf-8")
print("===============", d)
print("enter the option :\n1.FOR IP \n2.FOR SUBNET")
option = input(":--")
obj = Get()
if(option == "1"):
    i = obj.ip()
    print(i)

elif(option =="2"):
    s = obj.subnet()
    print(s)