import subprocess

process = subprocess.Popen("ipconfig", stdout=subprocess.PIPE)
display = process.communicate()[0]
d = display.decode("utf-8")
print("===============", d)
for line in d.splitlines():
    if line.lstrip().startswith("IPv4"):
        print("====")
        print("____the ip address is  :",line.split(":")[1])
    elif line.lstrip().startswith("Subnet"):
        print("\n____the subnet mask is :",line.split(":")[1])




