import time
import threading


def timee():
    print("time is: ", end='')
    print(time.ctime())



timee()