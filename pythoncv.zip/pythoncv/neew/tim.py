# import time
# import threading
#
# i = 0
#
# def timeer():
#     global i
#     if i < 3:
#         print("time is: ", end='')
#         print(time.asctime())
#         x = threading.Timer(2.0, timeer)
#         x.start()
#         print("threading ")
#         i += 1
#
#
#
# timeer()

PYTHONPATH=r"C:\Users\jouve\PycharmProjects\project3\new\package:$PYTHONPATH"
from project3.new.package import ii
fact(6)