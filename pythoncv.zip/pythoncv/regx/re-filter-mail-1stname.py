# import re
# s =[]
# n = int(input("enter the no of input: "))
# for i in range(n):
#     name,mail = input().strip().split(' ')
# name ,mail = [str(name),str(mail)]
#     s.append(mail.split())
# print(s)
import sys
import re

n = int(input().strip())
a = []
for i in range(n):
    name,email = input().strip().split(' ')
    name,mail = [str(name),str(email)]

    if re.search(r"@gmail\.com$",email):
        a.append(name)



a.sort()
for name in a
    print(name)