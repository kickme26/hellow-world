import re
d = "rabcdeefgyhfkioomnpoeroteeethyhlibnokltaad"
e = re.findall(r"[aeiou]{2,}",d)
for i in e:
    print(i)





#prints aeiou of length 2
