import re
st = "guna123_agy@ff   agyib@.sbb   sfd@yh.  ggg@gsdk.hjh  hsis@ksdhk.com"

print(re.findall("[\w._]{2,7}\@[\w]{2,20}\.[a-z]{2,3}",st))

print(re.findall("[\w*]{0,8}\@[\w*]{1,5}\.[\w*]{1,4}",st))
print(re.split(r" , \s",st))

