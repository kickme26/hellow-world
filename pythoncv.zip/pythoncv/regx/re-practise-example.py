import re

s = "a@afd bb@d.com scc dd e@fdfd4e.cd ab  ia q wyd wwnjebr e u b aba a ca CG Sfv \n abb abb@fd4353b baba.cdc \ ba jhh iuhdfa  a dad sa sab al brbbbb  bc "
print(re.findall("[a]+", s))
print("search ", re.search("ab", s))
print("match ", re.match(r"", s))
print("find: ", re.findall("ab", s))
print(re.findall(r"\b\w.", s))
print(re.findall(r"@\w*", s))
print(re.findall(r"@\w+", s))
print(re.findall(r"\w*\.\w*", s))
print(re.findall(r"\.(\w*)", s))
print(re.findall(r"(\w*)@", s))
d = "app ball elee doli ice dog \n unc cap naz cain ortho"
print(re.findall(r"\b[^aeiou ]\w+", d))
e = "982883 9328 23 2389 237 9329 9 999898988 98889273973 83292898 9876573654"
print("phn ", re.findall(r"[8-9]{1}[\d]{7,8}\d*", e))
print(re.findall(r"\w*@+", s))
print(re.findall(r"[^b ]\w+", s))
print(re.findall(r"[23]+", e))
print(re.findall(r"e@\w.+", s))