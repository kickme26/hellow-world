import pygame
import sys
from pygame.locals import*
pygame.init()
FPS = 30
fpsclock = pygame.time.Clock()
DISPLAYSURF = pygame.display.set_mode((400, 300), 0, 32)
pygame.display.set_caption("predict and earn")
white = (255, 255, 255)
while True:
    for e