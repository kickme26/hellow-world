import random


class Game:
    def __init__(self):



        self.points = 0
        self.generatenum = 0
        self.predictnum = 0
        self.name = input()

    def generate(self):

        self.generatenum = random.randint(0, 5)
        return self.generatenum

    def predict(self):
        self.name = (str(input("enter the name: ")))
        for chance in range(3):
            self.predictnum = int(input("hey {} enter the number either 0 or 1:  ".format(self.name)))

            if Game.generate(self) == self.predictnum:
                print("wow {} you found the exact number congrats%%%%".format(self.name))
                self.points = self.points + 10
                print(self.name, "your current total points :           ", self.points)
            else:
                print("your number:    ".ljust(30, "="), self.predictnum)
                print("generated number is:    ".ljust(30, "="), self.generatenum)
                self.points = self.points - 5
                print(self.name, "your current total points is:            ", self.points)
                print(f"\t!oops try again once", "you used {} chance".format(chance+1))
        print("{} your final points is :{}".format(self.name,self.points))
        print("well done now your turns ends now.Player 2 please press enter to  continue ")
    def get_x(self):
        return self.name

    def set_x(self, temp):
        self.name = temp
if __name__ == '__main__':

    ci = Game()
    ci.predict()

    c2 = Game()
    print("+++++++++++++++++++++player = 2 now its your turn++++++++++++++++++++++")
    c2.predict()






