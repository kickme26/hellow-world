# Data

id_data = {"1": "11", "2": "22", "3": "33"}
d_menu = {1: ("Idly", 30), 2: ("Poori", 20), 3: ("Briyani", 200), 4: ("Dosa", 30)}
menu = "    \nSelect\n1.Idly\n2.Poori\n3.Briyani\n4.Dosa"


class Log:
    def __init__(self):
        self.id = ''
        self.password = ''

    def login(self):
        self.id = input("ID: ")
        self.password = input("PASSWORD: ")
        # checking input ID and Password
        if self.id in id_data:
            if self.password == id_data.get(self.id):
                print("Successfully Logged in")

                return Home().order()
            else:
                print("Wrong password!")
        else:
            print("Your ID is not Valid")


class Home:
    def __init__(self):
        self.cart_item = ''
        self.choice = ''
        self.menu_item = []
        self.current_balance = 0
        self.order_sum = 0
        self.load_amount = ''
        self.pay_op = ''

    def order(self):
        print(menu, "Press '0' to view cart\nSelect the menu number: ")
        # Running while loop for selecting choice until the user selects '0'
        while True:
            self.choice = int(input(">>>"))
            if self.choice == 0:
                # print(dict(self.menu_item))
                # Changing the dict list to list
                cart_dict = list(self.menu_item)
                # print(cart_dict)
                # using loop for printing the item from list[cart_dict]
                order_item = [y[0] for y in cart_dict]
                print("Total Item: ", order_item)
                # using loop for printing the values from list[cart_dict]
                self.order_sum = [x[1] for x in cart_dict]
                print("==============", id(self.order_sum))


                print("Total Bill: ", int(sum(self.order_sum)))
                return Home().payingoption()
                # print(f"Items = {' , '.join(cart_dict.keys())}  'Total =' {sum(cart_dict.values())}")
            else:
                if self.choice in d_menu.keys():
                    t = self.choice
                    self.menu_item.append(d_menu.get(t))
                else:
                    print("\n!!--Select only form the given list--!!\n")

    def balance(self):

        print("Current balance: ", self.current_balance)
        return Home().payingoption()

    def payingoption(self):
        print("\n1. Pay now\n2. Pay later\n3. Balance\n")
        self.pay_op = int(input(">>  "))
        if self.pay_op == 1:
            return Home().paynow()
        # elif self.pay_op == 2:
        #     return Home().paylater()
        elif self.pay_op == 3:
            return Home().balance()

    def paynow(self):
        self.order()
        print(self.order_sum)
        print("==============", id(self.order_sum))
        print("paying now....")
        if self.current_balance > self.order_sum:
            self.current_balance = self.current_balance - self.order_sum
            return Home().balance()
        elif self.current_balance < self.order_sum:
            print("Oops! \n You dont have enough amount to pay the bill\n")
            return Home().loadmoney()

    def loadmoney(self):
        print("\nEnter the amount to load: ")
        self.load_amount = int(input(">>  "))
        self.current_balance = self.current_balance + self.load_amount
        return Home().balance()


if __name__ == '__main__':
    x = Log()
    x.login()
