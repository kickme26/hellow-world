import subprocess
class Get:
    def ip(self):
        for line in d.splitlines():
            if line.lstrip().startswith("IPv4"):
                print("====")
                print("____the ip address is  :",  line.split(":")[1])
    def subnet(self):
        for line in d.splitlines():
            if line.lstrip().startswith("Subnet"):
                print("\n____the subnet mask is :", line.split(":")[1])

process = subprocess.Popen("ipconfig", stdout=subprocess.PIPE)
display = process.communicate()[0]
d = display.decode("utf-8")
print("===============", d)
obj = Get()
obj.ip()
obj.subnet()
