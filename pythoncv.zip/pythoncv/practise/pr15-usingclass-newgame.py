import random
import time
from tqdm import tqdm


class Game:

    def __init__(self):
        self.name = input()

        self.generate_number = 0

    def generate(self):
        self.generate_number = random.randint(0, 10)
        return self.generate_number

    def predict(self):
        self.name = str(input("Enter the Player name: "))
        request = input(f"Hey {self.name} Press 'C' To SPIN :  ")
        if request == 'c':
            number = Game.generate(self)
            return number


if __name__ == '__main__':
    score1 = 0
    score2 = 0
    for chance in range(1):
        user1 = Game()
        user1number = user1.predict()
        print("Your number has been Generated Successfully :) Now Press ENTER")

        user2 = Game()
        print("\n=== Player 2 ===")
        user2number = user2.predict()
        print("DONE")
        for i in tqdm(range(100)):
            time.sleep(0.01)
        if user1number >= user2number:
            print(f"{user1.name} is a winner your number is {user1number}")
            print(f"{user2.name} better luck next time you got {user2number}")
            score1 = score1+25
        elif user2number >= user1number:
            print(f"{user2.name} is a winner your number is {user2number}")
            print(f"{user1.name} better luck next time your number is {user1number}")
            score2 = score2+25
print(f"\n{user1.name} FINAL SCORE IS ", score1)
print(f"{user2.name} FINAL SCORE IS ", score2)

