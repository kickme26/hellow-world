import os

for dname, dir, file in os.walk(r"C:\Users\jouve\PycharmProjects\untitled1\python cv\basics"):
    for fname in file:
        if fname.endswith(".txt"):
            new = os.path.join(dname, fname)
            print(new)
            with open(new, encoding="utf8") as d:
                read = d.read()
                st = str(read).split(" ")
                print(st)
            for i, words in enumerate(st):
                if words == "the":
                    print("=======", i, words)
            print("*******************************")
            print("enter the index")
            index = int(input(": "))
            print("string to replace")
            rep = list(str(input(": ")))
            reep = ("".join(rep))
            # print(reep)
            initar = st[:index]                                                    # slicing the array into two
            endar = st[index + 1:]
            # print(initar)
            # print(endar)
            finalarr = []                                                 # appending sliced list in new  array

            for x in initar:
                finalarr.append(x)                                                              # adding string

            finalarr.append(reep)

            for x in endar:                                                           # adding the second array
                finalarr.append(x)

            # print(str(finalarr).strip('[]'))
            print(', '.join(finalarr))
            wrt = (', '.join(finalarr).replace(", ", " "))
            print(wrt)
            # with open(new,"w") as new_write:
            #     new_write.write(wrt)
            #     print(wrt)
