'''l = "weimnxdcdc"
k = "jkdwnnjwlda"
d = [x for x in  l if x in k]
print(d)'''


'''def f(**kwargs):
    print (kwargs)
f(a=2,d=3)
'''
import os
import time
import calendar
from termcolor import colored
class Pythondev:
    def __init__(self,name,id,age):
        self.name = name
        self.id = id
        self.age = age
    def display(self):
        print("Name:\t",self.name,"id:\vt",self.id,"\tage :\v",self.age)
p1 = Pythondev("guna",7,21)
p2 = Pythondev("gely",5,20)

class Javadev:
    def __init__(self,name,id):
        self.name = name
        self.id = id
    def display(self):
        print("name:\t ",self.name,"id:\t ",self.id)

    def test(self):
        print("The test case ********************")

j1 = Javadev("jon",3)
j2 = Javadev("rock",5)

try :
    p1.display()
    p2.display()
    j1.display()
    j3.display()
    j2.display()
except NameError:
    print("name error found here")
    print(getattr(p1,"name"))    #getattr(obj,attr)
    print(hasattr(p1,"name"))    #has attr yes or no
    setattr(j1,"id",20)
    print(colored("after changing the attr of j1","green",j1.display()))
    print("emp doc",Pythondev.__doc__)
#print(getattr(p1,"mail"))
finally:
    n = input(("enter s to chek time and d to check date : "))
    if n == "s": print(time.ctime()),print("\nthe local time is: ",time.asctime(time.localtime(time.time())))
    elif n == "d": time.sleep(4), print(calendar.month(2015,5))

print("\n ****",time.ctime())
print("\n",time.asctime(time.localtime()))
print(calendar.firstweekday())
print(calendar.isleap(2109))
print(calendar.leapdays(1998,2019))
print(calendar.monthrange(1998,2))
class Dev(Javadev):
    def __init__(self):
        print("child class")
    def display(self):
        print("child method")
c1 = Dev()
c1.display()
c1.test()




