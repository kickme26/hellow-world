class Employee:
    def __init__(self, id, name, age, dob ,branch, experience):
        self.id = id
        self.name = name
        self.age = age
        self.dob = dob
        self.branch = branch
        self.experience = experience

    def display(self):

        print("ID: ", self.id,"\nNAME: ",self.name,"\nAGE: ",self.age,"\nDOB: ",self.dob,"\nBRANCH: ",self.branch,"\nEXPERIENCE: ",self.experience)

    def exp(self):
        if self.experience >2 and self.experience <4:
            print("software engineer")
        elif self.experience >=4:
            print("senior software engineer")
        else:
            print("junior software engineer")


    def get_x(self):
          return self.branch,self.name
    def set_x(self,value):
        self.branch = value



e1 = Employee(1, "jon", 21, 1998, "java", 5)

print("************************************")
print(e1.display())

"using get set"
e1.set_x("python")
print("------>",e1.get_x())


e2 = Employee(2, "don", 26, 1995, "python", 3)
e3 = Employee(3, "bon", 94, 1899, "python", 1)

e2.display()
e3.display()

e3.exp()
e2.exp()
























