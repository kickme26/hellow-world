from zipfile import ZipFile
import zipfile
import os
import sys
import shutil
import logging


'will create the output in the current working directly'

#shutil.make_archive("arch", "zip", r"E:\stest\scratches")
file_name = "arcch.zip"


logging.basicConfig(level=0)
shutil.make_archive("arch", "zip", r"E:\stest\scratches", logger=logging)
with zipfile.ZipFile(file_name, 'r') as d:
    print(d.namelist())

