import os
import sys
import glob
#
# for root,dir,file in os.walk(r"C:\Users\jouve\PycharmProjects\untitled1"):
#     for fname in file:
#         if fname.endswith(".txt"):
#             print(fname)
print("\n")

for fi in os.listdir(r"C:\Users\jouve\PycharmProjects\untitled1\python cv\basics"):
    # print(fi)
    # print(os.getcwd())
    if fi.endswith(".txt"):
        d = os.path.abspath(__file__)
        print(d)
        abs = os.path.abspath(fi)
        print(abs)
        open(f"{fi}","r").read()
        # if os.path.isfile(d):
        #     print("=====",d)
        #     with open(d,'r') as fd:
        #         lines = fd.readlines()
        #         print(lines)

rep = "****"
for dname,dir,file in os.walk(r"C:\Users\jouve\PycharmProjects\untitled1\python cv\basics"):
    for fname in file:
        if fname.endswith(".txt"):
            fpath = os.path.join(dname,fname)
            with open(fpath,encoding="utf8") as d:
                s = d.read()
            s = s.replace("is",rep)
            with open(fpath,"w")as f:
                f.write(s)
f.close()

import glob
         # create the list of file









