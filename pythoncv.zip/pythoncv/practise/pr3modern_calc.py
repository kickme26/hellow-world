import sys
from termcolor import colored,cprint
import  time

def add(a,b):
    c = a + b
    print(f"The sum of {a} and {b}: ",c)

def sub(a,b):
    c = a - b
    print(f"The subtraction of {a} and {b}: ", c)
def mul(a,b):
    c = a*b
    return c

def div(a,b):
    c= a//b
    return c

cprint("\n\n\t___----____simple calculator using functions____----____".expandtabs(13),'magenta',attrs=['bold'])

while  True:
    cprint("\n 1.Addition\n 2.Subtraction\n 3.Multiplictaion\n 4.Division\n 5.Exit",'green')
    cprint("\nenter the option:",'blue',attrs=['underline'])
    n = input("--->")
    if n == "5":
        print("you pressed 5 to exit:")
        time.sleep(0.8)
        print("closing the file")
        time.sleep(1.2)
        cprint("bye bye","red",attrs=["bold"])
        sys.exit()
    else:

        cprint("enter the input:  ","cyan",attrs=['reverse','blink'])
        try:
            x = int(input("a: "))
            y = int(input("b: "))
        except ValueError:
            cprint('####please enter only integer####', 'red')
            continue
    if n == "1":
        add(x,y)

    elif n == "2":
        sub(x,y)
    elif n=="3":
        ans = mul(x,y)
        print(f"after multiplying  {x} and {y}: ", ans)
    elif n == "4":
        ans = div(x,y)
        print(f"after multiplying  {x} and {y}: ", ans)


