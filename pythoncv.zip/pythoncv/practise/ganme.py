import random
import sys
count1 = 0
count2 = 0


def welcome():
    print("welcome".center(30, "="))
    Team1()


def hit():
    print("now press 's' to hit")
    inp = str(input())
    hi = None
    if inp == 's':
        hi = random.randint(0,10)
        return hi
    else:
        start()


def Team1():

    global count1
    print("Now its your Turn \t\tTeam 1  ")
    x1 = hit()
    print(x1)
    count1 = count1 + x1
    print(count1)
    if count1 >= 20:
        print("++++++you are the winner congrats++++++++")
    else:
        Team2()
    # count1= 0
    # while count1 <20:
    #     print("Now its your Turn \t\tTeam 1  ")
    #     x1 = hit()
    #     print(x1)
    #     count1 = count1 + x1
    # if count1 >= 20:
    #     print("++++++you are the winner congrats++++++++")
def Team2():
    global count2

    print("Now its your Turn \t\tTeam 2  ")
    x2 = hit()
    print(x2)
    count2 = count2 + x2
    print(count2)
    if count2 >= 20:
        print("++++++you are the winner congrats++++++++")
    else:
        Team1()


def start():
    print("welcome back to hit and count game \n\t\t press \t'c'\tto enter the gsme ")
    st = str(input(":---->"))
    if st == 'c':
        welcome()
    else:
        print("are you sure want to exit? press 'x' to terminate or 'y' to go back" )
        su = input()
        if su == 'y':
            start()
        else:
            print("have a good day bye")
            sys.exit()


start()











# def Team1():
#
#     count1= 0
#     while count1 <20:
#         print("Now its your Turn \t\tTeam 1  ")
#         x1 = hit()
#         print(x1)
#         count1 = count1 + x1
#     if count1 >= 20:
#         print("++++++you are the winner congrats++++++++")
#







