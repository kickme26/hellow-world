

#searching for directory and files and storing them in a list

import os,sys
d = open("E:\stest","r")
l = os.listdir(d)

[prem,kumar.py,kumar,man.py]
directoy=[]
file=[]
for i in l:
    if os.path.isdir(l):

        os.path.join(i,'.'.join(directoy,i))
