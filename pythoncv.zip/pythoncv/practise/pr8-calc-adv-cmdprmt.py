from termcolor import cprint
while True:
    cprint(">>>","green")
    try:
        n = input("")

        l = list(n.split(" "))
    except IndexError :
        print (" please leave space between two operand :")




    if l[1] == "+":
        ans = int(l[0]) + int(l[2])
        print(ans)
    elif l[1] == "-":
        ans = int(l[0]) - int(l[2])
        print(ans)
    elif l[1] == "*":
        ans = int(l[0]) * int(l[2])
        print(ans)
    elif l[1] == "/":
        ans = int(l[0]) / int(l[2])
        print(ans)

