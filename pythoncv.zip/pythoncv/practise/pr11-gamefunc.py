

import random
import sys

# def user1(self):
points1 = 0
points2 = 0


def welcome():
    print("welcome".center(30, "="))
    player1()


def hit():
    print("now press 's' to hit")
    inp = str(input())
    hi = None
    if inp == 's':
        hi = random.randint(1,5)
        return hi
    else:
        start()


def player1():
    global points1
    while points1 < 20:
        print("Now its your Turn \t\tPlayer 1 ")
        x1 = hit()
        num = predict()
        if num == x1:
            print("----wow you found the exact number----")
            print("your prediction:", num)
            print("generated number:", x1)

            points1 = points1 + 10
            print(points1)

        elif num != x1:
            print("---oops! that's not the exact one better luck next time :) *---")
            print("generated number:", x1)
            print("your prediction:", num)
            print(points1)
        if points1 >= 20:
            print("++++++you are the winner congrats++++++++")
            start()
        else:
            player2()


def player2():
    global points2
    while points2 < 20:
        print("Now its your Turn \t\tPlayer 2  ")
        x2 = hit()
        num = predict()
        if num == x2:
            print("----wow you found the exact number----")
            print("your prediction:", num)
            print("generated number:", x2)

            points2 = points2 + 10
            print(points2)

        elif num != x2:
            print("---oops! that's not the exact one better luck next time :) *---")
            print("generated number:",x2)
            print("your prediction:", num)
            print(points2)
        if points2 >= 20:
            print("++++++you are the winner congrats++++++++")
            start()
        else:
            player1()


def predict():
    print("What number will it  generate now { 1 - 7  }")
    number = input("========>")
    return number


def start():
    print("welcome back to hit and count game \n\t\t press \t'c'\tto enter the gsme ")
    st = str(input(":---->"))
    if st == 'c':
        welcome()
    else:
        print("are you sure want to exit? press 'x' to terminate or 'y' to go back")
        su = input()
        if su == 'y':
            start()
        else:
            print("have a good day bye")
            sys.exit()


if __name__ == '__main__':
    start()
