
import random

s = "abcdefghijklmnopqrstuvwxyz01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()?"
passwordlen = 8
p =  "".join(random.sample(s,passwordlen ))
print (p)
