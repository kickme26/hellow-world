import sys
print("enter 5 to exit or any key to enter:  ")
ex = input()
if ex == "5":
    sys.exit()
else:
    while True:
        print("Simple calculator\n 1.Addition\n 2.Subtraction\n 3.Multiplictaion\n 4.Division\n  " )
        print("please select the option to perform operation")
        operation = input()

        print("enter the inputs: A and B:")
        a = int(input())
        b = int(input())
        if operation == "1":
            c = a + b
            print("the sum is: ",c)
        elif operation == "2":
            c = a - b
            print(c)
        elif operation == "3":
            c = a * b
            print("the product is :",c)
        elif operation == "4":
            c  = a // b
            print("the quotient is: ",c)
